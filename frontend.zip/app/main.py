# ============================================================
# 🚀 AI Price Optimization API (FastAPI + LightGBM Model)
# ============================================================

from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import pandas as pd
import numpy as np
import os

# ---------------------------------------------------
# 🚀 Initialize FastAPI
# ---------------------------------------------------
app = FastAPI(
    title="AI Dynamic Pricing API",
    description="Predict optimized ride prices using a trained LightGBM model",
    version="1.1"
)

# ---------------------------------------------------
# 🧠 Load model and feature columns
# ---------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "backtest_lgbm_model.joblib")
FEATURES_PATH = os.path.join(BASE_DIR, "feature_columns.pkl")

print(f"🔍 Loading model from: {MODEL_PATH}")

try:
    model = joblib.load(MODEL_PATH)
    feature_columns = joblib.load(FEATURES_PATH)
    print("✅ Model and feature columns loaded successfully!")
except Exception as e:
    print("❌ Error loading model or feature columns:", e)
    model = None
    feature_columns = None

# ---------------------------------------------------
# 📦 Define input schema for API requests
# ---------------------------------------------------
class PriceInput(BaseModel):
    Number_of_Riders: int
    Number_of_Drivers: int
    Customer_Loyalty_Status: str
    Number_of_Past_Rides: int
    Average_Ratings: float
    Expected_Ride_Duration: float
    Time_of_Booking: str
    Vehicle_Type: str
    Location_Category: str
from fastapi.middleware.cors import CORSMiddleware

from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)



# ---------------------------------------------------
# 🏠 Root Endpoint
# ---------------------------------------------------
@app.get("/")
def home():
    return {"message": "🚀 AI Dynamic Pricing API is running successfully!"}

# ---------------------------------------------------
# 🔮 Prediction Endpoint
# ---------------------------------------------------
@app.post("/predict")
def predict_price(data: PriceInput):
    if model is None or feature_columns is None:
        return {"error": "Model or feature columns not loaded.", "status": "failed"}

    try:
        # Convert input to DataFrame
        df = pd.DataFrame([data.dict()])

        # --- Feature Engineering (match training logic) ---
        df["Demand_Supply_Ratio"] = df["Number_of_Riders"] / (df["Number_of_Drivers"] + 1)
        df["Ride_Experience"] = df["Number_of_Past_Rides"] * df["Average_Ratings"]
        df["Ride_Intensity"] = df["Demand_Supply_Ratio"] * np.sqrt(df["Ride_Experience"])

        # Loyalty encoding
        loyalty_map = {"Regular": 0, "Silver": 1, "Gold": 2}
        df["Customer_Loyalty_Status"] = df["Customer_Loyalty_Status"].map(loyalty_map)

        # One-hot encoding for categorical columns
        df = pd.get_dummies(
            df,
            columns=["Location_Category", "Time_of_Booking", "Vehicle_Type"],
            drop_first=True
        )

        # Add any missing columns (for alignment with training features)
        for col in feature_columns:
            if col not in df.columns:
                df[col] = 0

        # Reorder columns
        df = df[feature_columns]

        # --- Make Prediction ---
        predicted_log_price = model.predict(df)[0]
        predicted_price = float(round(np.expm1(predicted_log_price), 2))  # reverse log transform

        return {
            "predicted_price": predicted_price,
            "currency": "₹",
            "status": "success"
        }

    except Exception as e:
        return {"error": str(e), "status": "failed"}

# ---------------------------------------------------
# 🧪 Run locally
# ---------------------------------------------------
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000, reload=True)
