// frontend/src/Navbar.js

import React from 'react';
import { Link } from 'react-router-dom';

function Navbar() {
  return (
    <nav className="navbar">
      <div className="navbar-brand">
        AI Price Optima
      </div>
      <div className="navbar-links">
        <Link to="/">🏠 Project Summary</Link>
        <Link to="/predict">💡 Dynamic Pricing Tool</Link>
        <Link to="/insights">📊 Model Insights</Link>
        <Link to="/kpi">🧪 Backtesting & KPI</Link>
      </div>
    </nav>
  );
}

export default Navbar;