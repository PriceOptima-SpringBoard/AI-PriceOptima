import React, { useState } from "react";
import axios from "axios";
import {
  TextField,
  Button,
  Card,
  CardContent,
  Typography,
  Grid,
  Box,
} from "@mui/material";

function App() {
  const [formData, setFormData] = useState({
    Number_of_Riders: 90,
    Number_of_Drivers: 45,
    Customer_Loyalty_Status: "Silver",
    Number_of_Past_Rides: 13,
    Average_Ratings: 4.47,
    Time_of_Booking: "Night",
    Vehicle_Type: "Premium",
    Expected_Ride_Duration: 90,
    Location_Category: "Urban",
    Historical_Cost_of_Ride: 284.25,
  });

  const [result, setResult] = useState(null);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const payload = {
      Number_of_Riders: Number(formData.Number_of_Riders),
      Number_of_Drivers: Number(formData.Number_of_Drivers),
      Customer_Loyalty_Status: formData.Customer_Loyalty_Status,
      Number_of_Past_Rides: Number(formData.Number_of_Past_Rides),
      Average_Ratings: Number(formData.Average_Ratings),
      Time_of_Booking: formData.Time_of_Booking,
      Vehicle_Type: formData.Vehicle_Type,
      Expected_Ride_Duration: Number(formData.Expected_Ride_Duration),
      Location_Category: formData.Location_Category,
      Historical_Cost_of_Ride: Number(formData.Historical_Cost_of_Ride),
    };

    try {
      const response = await axios.post("http://127.0.0.1:8000/predict", payload);
      setResult(response.data);
    } catch (error) {
      alert("Prediction failed. Check backend console.");
    }
  };

  return (
    <Box
      sx={{
        minHeight: "100vh",
        background: "linear-gradient(to right, #4b79a1, #283e51)",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        padding: 4,
      }}
    >
      <Card sx={{ width: "70%", borderRadius: 4, boxShadow: 6 }}>
        <CardContent>
          <Typography variant="h4" textAlign="center" fontWeight="bold" mb={3}>
            🚖 AI Dynamic Pricing Prediction
          </Typography>

          <form onSubmit={handleSubmit}>
            <Grid container spacing={2}>
              {Object.keys(formData).map((key) => (
                <Grid item xs={12} sm={6} key={key}>
                  <TextField
                    fullWidth
                    label={key.replaceAll("_", " ")}
                    name={key}
                    value={formData[key]}
                    onChange={handleChange}
                    variant="outlined"
                  />
                </Grid>
              ))}
            </Grid>

            <Button
              variant="contained"
              fullWidth
              size="large"
              type="submit"
              sx={{ mt: 3, backgroundColor: "#1e88e5", paddingY: 1.5 }}
            >
              Predict Price
            </Button>
          </form>

          {result && (
            <Box
              sx={{
                mt: 4,
                background: "#e3f2fd",
                padding: 3,
                borderRadius: 3,
                textAlign: "center",
              }}
            >
              <Typography variant="h5" fontWeight="bold">
                Prediction Result
              </Typography>
              <Typography variant="h6" mt={1}>
                Predicted Price: <b>₹{result.predicted_price}</b>
              </Typography>
              <Typography>Status: {result.status}</Typography>
            </Box>
          )}
        </CardContent>
      </Card>
    </Box>
  );
}

export default App;
