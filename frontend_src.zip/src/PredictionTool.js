// frontend/src/PredictionTool.js

import React, { useState } from 'react';
import axios from 'axios';

// --- Static Options for Dropdowns ---
const CATEGORY_OPTIONS = ['Urban', 'Suburban', 'Rural'];
const LOYALTY_OPTIONS = ['Regular', 'Silver', 'Gold'];
const TIME_OPTIONS = ['Morning', 'Afternoon', 'Evening', 'Night'];
const VEHICLE_OPTIONS = ['Economy', 'Premium'];

function PredictionTool() {
  // 1. STATE MANAGEMENT: Store form data and results
  const [formData, setFormData] = useState({
    Number_of_Riders: 50,
    Number_of_Drivers: 30,
    Number_of_Past_Rides: 50,
    Average_Ratings: 4.5,
    Expected_Ride_Duration: 60,
    Location_Category: 'Urban',
    Customer_Loyalty_Status: 'Gold',
    Time_of_Booking: 'Morning',
    Vehicle_Type: 'Premium',
  });
  const [predictedPrice, setPredictedPrice] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // 2. HANDLERS
  const handleChange = (e) => {
    const { name, value, type } = e.target;
    // Convert numbers to float/int if they are number inputs
    const newValue = type === 'number' ? parseFloat(value) : value;
    setFormData({ ...formData, [name]: newValue });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setPredictedPrice(null);
    setError('');

    try {
      // NOTE: FastAPI runs on port 8000
      const response = await axios.post('http://localhost:8000/predict_price', formData);
      setPredictedPrice(response.data.predicted_price);
    } catch (err) {
      console.error('API Error:', err);
      setError('Prediction failed. Ensure the FastAPI service is running at http://localhost:8000.');
    } finally {
      setLoading(false);
    }
  };

  // 3. DERIVED FEATURES (Displayed to the user)
  const demandSupplyRatio = (formData.Number_of_Riders / (formData.Number_of_Drivers + 1)).toFixed(2);
  const rideExperience = (formData.Number_of_Past_Rides * formData.Average_Ratings).toFixed(2);

  return (
    <div className="page-content">
      <h2>💡 Dynamic Pricing Tool</h2>
      <p>Enter the ride features below to receive a real-time price prediction from the LGBM model.</p>
      
      <div className="prediction-grid">
        
        {/* === Input Form (Left Side) === */}
        <form onSubmit={handleSubmit} className="input-form">
          {Object.keys(formData).map((key) => {
            let type = typeof formData[key] === 'number' ? 'number' : 'select';
            let label = key.replace(/_/g, ' ');

            // Use select/dropdown for categorical features
            if (CATEGORY_OPTIONS.includes(formData[key]) || LOYALTY_OPTIONS.includes(formData[key]) || TIME_OPTIONS.includes(formData[key]) || VEHICLE_OPTIONS.includes(formData[key])) {
              type = 'select';
            }

            return (
              <div className="form-group" key={key}>
                <label>{label}:</label>
                {type === 'number' ? (
                  <input
                    type="number"
                    step="0.01"
                    name={key}
                    value={formData[key]}
                    onChange={handleChange}
                    required
                  />
                ) : (
                  <select name={key} value={formData[key]} onChange={handleChange}>
                    {(key === 'Location_Category' ? CATEGORY_OPTIONS : 
                      key === 'Customer_Loyalty_Status' ? LOYALTY_OPTIONS : 
                      key === 'Time_of_Booking' ? TIME_OPTIONS : 
                      VEHICLE_OPTIONS
                    ).map(option => (
                      <option key={option} value={option}>{option}</option>
                    ))}
                  </select>
                )}
              </div>
            );
          })}
          
          <button type="submit" disabled={loading}>
            {loading ? 'Predicting...' : 'Predict Dynamic Price'}
          </button>
        </form>

        {/* === Results & Derived Features (Right Side) === */}
        <div className="results-panel">
          <h3>Prediction Results</h3>
          {error && <p className="error">{error}</p>}

          <div className="derived-features-box">
            <h4>Derived Features</h4>
            <div className="derived-feature-item">
              <strong>Demand/Supply Ratio:</strong> <span>{demandSupplyRatio}</span>
              <p className="hint">({formData.Number_of_Riders} Riders / ({formData.Number_of_Drivers} Drivers + 1))</p>
            </div>
            <div className="derived-feature-item">
              <strong>Ride Experience:</strong> <span>{rideExperience}</span>
              <p className="hint">({formData.Number_of_Past_Rides} Rides × {formData.Average_Ratings} Rating)</p>
            </div>
          </div>
          
          {predictedPrice !== null && (
            <div className="final-prediction-box">
              <p>The model predicts the optimal ride price is:</p>
              <p className="predicted-price-value">₹ {predictedPrice.toLocaleString()}</p>
            </div>
          )}
          
          {!predictedPrice && !loading && !error && (
            <p className="hint-message">Enter values and click 'Predict' to calculate the dynamic price.</p>
          )}
        </div>
      </div>
    </div>
  );
}

export default PredictionTool;