// frontend/src/Home.js

import React from 'react';

function Home() {
  return (
    <div className="page-content">
      <h2>🏠 Dynamic Pricing Optimization Project</h2>
      <p className="lead">Welcome to the AI-Powered solution for maximizing revenue in ride-sharing by dynamically adjusting prices based on real-time factors.</p>

      <div className="summary-section">
        <h3>Project Goal</h3>
        <p>The primary objective is to develop a machine learning model that predicts the optimal, dynamic price for a ride. This price is designed to balance driver utilization, rider demand, and ultimately **maximize total revenue** (measured by Simulated Revenue Lift) compared to a static or rule-based baseline.</p>
      </div>

      <div className="summary-section">
        <h3>Core Components</h3>
        <ul>
          <li><strong>Data Ingestion & Cleaning:</strong> Handled missing values (imputed by median/mode) and ensured data quality.</li>
          <li><strong>Feature Engineering:</strong> Created powerful predictors like **Demand/Supply Ratio** and **Ride Experience**.</li>
          <li><strong>Model Selection:</strong> Used **LightGBM (LGBMRegressor)**, an advanced gradient boosting framework, for superior performance and non-linear relationship modeling.</li>
          <li><strong>Deployment:</strong> Served the trained model via a **FastAPI** backend for low-latency, real-time predictions.</li>
        </ul>
      </div>
      
      <p className="call-to-action">Navigate to the "Dynamic Pricing Tool" to see the model in action!</p>
    </div>
  );
}

export default Home;