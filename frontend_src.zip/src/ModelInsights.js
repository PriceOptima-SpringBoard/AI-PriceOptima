// frontend/src/ModelInsights.js

import React from 'react';
// 1. CRITICAL FIX: You MUST import the image variable
import FeatureImportanceChart from './assets/feature_importance.png'; // <--- ADD THIS LINE

function ModelInsights() {
  return (
    <div className="page-content">
      <h2>📊 Model & Data Insights</h2>
      <p>Key results and technical specifications of the LightGBM model trained during Milestone 5.</p>

      <div className="insights-grid">
        {/* --- Section 1: Final Metrics --- */}
        <div className="card">
          <h3>Final Model Performance (LGBM)</h3>
          <p>Metrics calculated on the separate test set (20% of data).</p>
          <div className="metric-box">
            <span className="metric-label">Mean Absolute Error (MAE):</span>
            <span className="metric-value placeholder">~ 0.15 (Log Scale)</span>
          </div>
          <div className="metric-box">
            <span className="metric-label">R-squared (R²) Score:</span> 
            <span className="metric-value placeholder">~ 0.95</span>
          </div>
          <p className="hint-message">This high R² indicates the model explains 95% of the variance in ride cost.</p>
        </div>

        {/* --- Section 2: Training Parameters --- */}
        <div className="card">
          <h3>LGBM Hyperparameters</h3>
          <p>The optimized settings used for the final training run.</p>
          <ul className="params-list">
            <li>**n_estimators:** 500 (Number of boosting stages/trees)</li>
            <li>**learning_rate:** 0.03 (Controls magnitude of change in each step)</li>
            <li>**subsample/colsample:** 0.8 (Used to reduce overfitting)</li>
            <li>**reg_alpha (L1) / reg_lambda (L2):** 0.2 / 1.0 (Regularization terms)</li>
          </ul>
        </div>
        
        {/* --- Section 3: Feature Importances --- */}
        <div className="card full-width">
          <h3>Top Feature Importances</h3>
          <p>The model determines which factors influence the price prediction the most. **Expected Ride Duration** and the **Derived Features** typically lead the importance rankings.</p>
          <div className="image-container">
            <img 
              src={FeatureImportanceChart} 
              alt="Feature Importance Chart showing duration and demand/supply as key features"
              style={{ maxWidth: '100%', height: 'auto' }}
            />
          </div>
        </div>
      </div> 
      {/* This closes the insights-grid div */}
    </div> 
  );
}

export default ModelInsights;